package es.unex.dinopedia.Interfaz;

import es.unex.dinopedia.Model.Dinosaurio;

public interface MainActivityInterface {

    void classDinosaurio(Dinosaurio d);

}
